/* =========================================================
   HITO 4: MANTENEDOR DE PRODUCTOS (productos.html)
   ========================================================= */
let selectedProductId = null;
let productFormMode = 'create';

function toggleSelectProduct(id) {
  document.getElementById('products-list-alert').classList.add('hidden');
  selectedProductId = selectedProductId === id ? null : id;
  renderProductsTable();
}

function renderProductsTable() {
  const products = getProducts();
  let html = '';
  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    const isChecked = selectedProductId === p.id;
    const badgeCls = p.estado === 'Habilitado' ? 'badge-enabled' : 'badge-disabled';
    html += '<tr class="' + (isChecked ? 'selected-row' : '') + '">' +
      '<td class="col-check"><input type="checkbox" ' + (isChecked ? 'checked' : '') + ' onchange="toggleSelectProduct(\'' + p.id + '\')"></td>' +
      '<td>' + p.id + '</td>' +
      '<td>' + p.nombre + '</td>' +
      '<td>' + p.cantidad + '</td>' +
      '<td>' + formatCLP(p.valor) + '</td>' +
      '<td><span class="status-badge ' + badgeCls + '">' + p.estado + '</span></td>' +
    '</tr>';
  }
  document.getElementById('tb-products').innerHTML = html;
  document.getElementById('btn-edit-product').disabled = selectedProductId === null;
  document.getElementById('btn-delete-product').disabled = selectedProductId === null;
}

function clearProductFields() {
  document.getElementById('prod-nombre').value = '';
  document.getElementById('prod-cantidad').value = '';
  document.getElementById('prod-valor').value = '';
  document.getElementById('prod-estado').value = 'Habilitado';
  document.getElementById('stock-zero-note').classList.add('hidden');
}

function checkZeroStockRule() {
  const raw = document.getElementById('prod-cantidad').value;
  if (raw !== '' && parseInt(raw, 10) === 0) {
    document.getElementById('prod-estado').value = 'Deshabilitado';
    document.getElementById('stock-zero-note').classList.remove('hidden');
  } else {
    document.getElementById('stock-zero-note').classList.add('hidden');
  }
}

function openProductForm(mode) {
  productFormMode = mode;
  document.getElementById('product-form-alert').classList.add('hidden');
  const products = getProducts();

  if (mode === 'create') {
    let nextNum = 1001;
    for (let i = 0; i < products.length; i++) {
      const n = parseInt(products[i].id, 10);
      if (!isNaN(n) && n >= nextNum) {
        nextNum = n + 1;
      }
    }
    document.getElementById('product-form-title').textContent = 'Ingresar producto';
    document.getElementById('prod-id').value = String(nextNum);
    clearProductFields();
  } else {
    let found = null;
    for (let i = 0; i < products.length; i++) {
      if (products[i].id === selectedProductId) {
        found = products[i];
        break;
      }
    }
    if (!found) return;
    document.getElementById('product-form-title').textContent = 'Editar producto';
    document.getElementById('prod-id').value = found.id;
    document.getElementById('prod-nombre').value = found.nombre;
    document.getElementById('prod-cantidad').value = found.cantidad;
    document.getElementById('prod-valor').value = found.valor;
    document.getElementById('prod-estado').value = found.estado;
    checkZeroStockRule();
  }

  document.getElementById('view-products-list').classList.add('hidden');
  document.getElementById('view-product-form').classList.remove('hidden');
}

function returnToProductsList() {
  document.getElementById('view-product-form').classList.add('hidden');
  document.getElementById('view-products-list').classList.remove('hidden');
  selectedProductId = null;
  renderProductsTable();
}

function saveProductForm() {
  const id = document.getElementById('prod-id').value.trim();
  const nombre = document.getElementById('prod-nombre').value.trim();
  const cantidad = parseInt(document.getElementById('prod-cantidad').value, 10);
  const valor = parseInt(document.getElementById('prod-valor').value, 10);
  let estado = document.getElementById('prod-estado').value;
  const alertEl = document.getElementById('product-form-alert');

  if (!nombre || isNaN(cantidad) || cantidad < 0 || isNaN(valor) || valor <= 0) {
    alertEl.textContent = 'Completa todos los campos con valores numéricos válidos.';
    alertEl.classList.remove('hidden');
    return;
  }
  if (cantidad === 0) {
    estado = 'Deshabilitado';
  }

  const products = getProducts();
  if (productFormMode === 'edit') {
    for (let i = 0; i < products.length; i++) {
      if (products[i].id === id) {
        products[i].nombre = nombre;
        products[i].cantidad = cantidad;
        products[i].valor = valor;
        products[i].estado = estado;
        break;
      }
    }
  } else {
    products.push({
      id: id,
      nombre: nombre,
      cantidad: cantidad,
      valor: valor,
      estado: estado,
      usado: false
    });
  }

  saveProducts(products);
  openActionModal('Producto guardado', 'Los cambios en el catálogo se guardaron correctamente.', false, [
    { text: 'Volver al listado', cls: 'btn-secondary', onClick: function() { closeActionModal(); returnToProductsList(); } }
  ]);
}

function confirmDeleteProduct() {
  if (selectedProductId === null) return;
  const idToDelete = selectedProductId;
  const orders = getOrders();
  for (let i = 0; i < orders.length; i++) {
    for (let j = 0; j < orders[i].items.length; j++) {
      if (orders[i].items[j].productoId === idToDelete) {
        const alertEl = document.getElementById('products-list-alert');
        alertEl.textContent = 'No se puede eliminar el producto N° ' + idToDelete + ' porque está asociado a pedidos ingresados.';
        alertEl.classList.remove('hidden');
        return;
      }
    }
  }

  openActionModal('¿Eliminar producto?', 'El producto N° ' + idToDelete + ' se eliminará de forma permanente.', true, [
    { text: 'Cancelar', cls: 'btn-outline', onClick: closeActionModal },
    { text: 'Eliminar', cls: 'btn-danger', onClick: function() {
      const products = getProducts();
      const remaining = [];
      for (let i = 0; i < products.length; i++) {
        if (products[i].id !== idToDelete) {
          remaining.push(products[i]);
        }
      }
      saveProducts(remaining);
      selectedProductId = null;
      closeActionModal();
      renderProductsTable();
    }}
  ]);
}

document.addEventListener('DOMContentLoaded', function() {
  renderProductsTable();
  document.getElementById('btn-new-product').addEventListener('click', function() { openProductForm('create'); });
  document.getElementById('btn-edit-product').addEventListener('click', function() { openProductForm('edit'); });
  document.getElementById('btn-delete-product').addEventListener('click', confirmDeleteProduct);
  document.getElementById('prod-cantidad').addEventListener('input', checkZeroStockRule);
  document.getElementById('prod-estado').addEventListener('change', checkZeroStockRule);
  document.getElementById('btn-back-products').addEventListener('click', returnToProductsList);
  document.getElementById('btn-clear-product').addEventListener('click', clearProductFields);
  document.getElementById('btn-save-product').addEventListener('click', saveProductForm);
});
