/* =========================================================
   HITO 3: CREACIÓN Y EDICIÓN DE PEDIDOS (pedidos.html)
   ========================================================= */
let orderLines = [];
let editingOrderId = null;

function formatRunInput(inp) {
  let clean = inp.value.replace(/[^0-9kK]/g, '').toUpperCase();
  if (clean.length > 1) {
    inp.value = clean.slice(0, -1).replace(/\B(?=(\d{3})+(?!\d))/g, '.') + '-' + clean.slice(-1);
  } else {
    inp.value = clean;
  }
}

function isValidRun(run) {
  const clean = run.replace(/[^0-9kK]/g, '').toUpperCase();
  if (clean.length < 8) return false;
  const body = clean.slice(0, -1);
  const dv = clean.slice(-1);
  let sum = 0;
  let mul = 2;
  for (let i = body.length - 1; i >= 0; i--) {
    sum += parseInt(body[i], 10) * mul;
    mul = mul === 7 ? 2 : mul + 1;
  }
  const rem = 11 - (sum % 11);
  const expected = rem === 11 ? '0' : (rem === 10 ? 'K' : String(rem));
  return dv === expected;
}

function searchProductLine(idx, text) {
  orderLines[idx].texto = text;
  orderLines[idx].productoId = null;
  orderLines[idx].valorUnitario = 0;

  const box = document.getElementById('sug-' + idx);
  if (text.trim().length < 3) {
    box.classList.add('hidden');
    document.getElementById('ord-total').textContent = formatCLP(calcOrderTotal(orderLines));
    return;
  }

  const products = getProducts();
  let html = '';
  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    if (p.estado === 'Habilitado' && p.cantidad > 0 && p.nombre.toLowerCase().indexOf(text.trim().toLowerCase()) !== -1) {
      html += '<div class="autocomplete-item" onclick="selectProductLine(' + idx + ', \'' + p.id + '\')">' +
        '<span>' + p.nombre + '</span>' +
        '<span>' + formatCLP(p.valor) + ' (Stock: ' + p.cantidad + ')</span>' +
      '</div>';
    }
  }
  box.innerHTML = html || '<div class="autocomplete-item"><span>Sin coincidencias disponibles</span></div>';
  box.classList.remove('hidden');
}

function selectProductLine(idx, productId) {
  const products = getProducts();
  for (let i = 0; i < products.length; i++) {
    if (products[i].id === productId) {
      orderLines[idx].productoId = products[i].id;
      orderLines[idx].texto = products[i].nombre;
      orderLines[idx].valorUnitario = products[i].valor;
      break;
    }
  }
  renderOrderLines();
}

function updateLineQty(idx, val) {
  const qty = parseInt(val, 10);
  orderLines[idx].cantidad = isNaN(qty) || qty < 1 ? 1 : qty;
  renderOrderLines();
}

function removeOrderLine(idx) {
  if (orderLines.length === 1) {
    orderLines[0] = { cantidad: 1, texto: '', productoId: null, valorUnitario: 0 };
  } else {
    orderLines.splice(idx, 1);
  }
  renderOrderLines();
}

function renderOrderLines() {
  let html = '';
  for (let i = 0; i < orderLines.length; i++) {
    const line = orderLines[i];
    const unitText = line.productoId ? formatCLP(line.valorUnitario) : '';
    const subText = line.productoId ? formatCLP(line.cantidad * line.valorUnitario) : '';
    html += '<div class="order-line-row">' +
      '<input type="number" class="form-control" min="1" value="' + line.cantidad + '" onchange="updateLineQty(' + i + ', this.value)">' +
      '<div class="autocomplete-wrap">' +
        '<input type="text" class="form-control" placeholder="Escribe al menos 3 letras..." value="' + line.texto + '" oninput="searchProductLine(' + i + ', this.value)">' +
        '<div id="sug-' + i + '" class="autocomplete-list hidden"></div>' +
      '</div>' +
      '<input type="text" class="form-control" readonly value="' + unitText + '">' +
      '<input type="text" class="form-control" readonly value="' + subText + '">' +
      '<button type="button" class="btn btn-outline" style="padding:0.5rem;" onclick="removeOrderLine(' + i + ')" title="Quitar fila">🗑</button>' +
    '</div>';
  }
  document.getElementById('order-lines-container').innerHTML = html;
  document.getElementById('ord-total').textContent = formatCLP(calcOrderTotal(orderLines));
}

function resetOrderForm() {
  editingOrderId = null;
  localStorage.removeItem(STORAGE_KEYS.EDIT_ORDER_ID);
  document.getElementById('order-form-title').textContent = 'Nuevo pedido';
  document.getElementById('btn-cancel-edit').classList.add('hidden');
  document.getElementById('order-alert').classList.add('hidden');
  document.getElementById('ord-nombre').value = '';
  document.getElementById('ord-run').value = '';
  document.getElementById('ord-telefono').value = '';
  document.getElementById('ord-correo').value = '';
  document.getElementById('ord-direccion').value = '';
  orderLines = [{ cantidad: 1, texto: '', productoId: null, valorUnitario: 0 }];
  renderOrderLines();
}

function showOrderError(msg) {
  const alertEl = document.getElementById('order-alert');
  alertEl.textContent = msg;
  alertEl.classList.remove('hidden');
}

function submitOrder() {
  const nombre = document.getElementById('ord-nombre').value.trim();
  const run = document.getElementById('ord-run').value.trim();
  const telefono = document.getElementById('ord-telefono').value.trim();
  const correo = document.getElementById('ord-correo').value.trim();
  const direccion = document.getElementById('ord-direccion').value.trim();

  if (!nombre || !run || !telefono || !correo || !direccion) {
    return showOrderError('Completa todos los campos obligatorios (*).');
  }
  if (!isValidRun(run)) {
    return showOrderError('El RUN ingresado no es válido.');
  }
  if (correo.indexOf('@') === -1) {
    return showOrderError('El correo electrónico no es válido.');
  }

  const products = getProducts();
  const validItems = [];
  for (let i = 0; i < orderLines.length; i++) {
    const line = orderLines[i];
    if (line.productoId) {
      let prod = null;
      for (let j = 0; j < products.length; j++) {
        if (products[j].id === line.productoId) {
          prod = products[j];
          break;
        }
      }
      if (!prod || prod.estado !== 'Habilitado') {
        return showOrderError('El producto "' + line.texto + '" no está disponible.');
      }
      if (line.cantidad > prod.cantidad) {
        return showOrderError('Stock insuficiente para ' + prod.nombre + ' (disponible: ' + prod.cantidad + ').');
      }
      validItems.push({
        productoId: prod.id,
        nombre: prod.nombre,
        cantidad: line.cantidad,
        valorUnitario: prod.valor
      });
    }
  }

  if (validItems.length === 0) {
    return showOrderError('Agrega al menos un producto válido al detalle.');
  }

  document.getElementById('order-alert').classList.add('hidden');
  const orders = getOrders();

  if (editingOrderId !== null) {
    for (let k = 0; k < orders.length; k++) {
      if (orders[k].id === editingOrderId) {
        orders[k].nombre = nombre;
        orders[k].run = run;
        orders[k].telefono = telefono;
        orders[k].correo = correo;
        orders[k].direccion = direccion;
        orders[k].items = validItems;
        break;
      }
    }
    localStorage.removeItem(STORAGE_KEYS.EDIT_ORDER_ID);
  } else {
    let nextId = 1;
    for (let m = 0; m < orders.length; m++) {
      if (orders[m].id >= nextId) {
        nextId = orders[m].id + 1;
      }
    }
    orders.push({
      id: nextId,
      nombre: nombre,
      run: run,
      telefono: telefono,
      correo: correo,
      direccion: direccion,
      vb: '—',
      envio: '—',
      items: validItems
    });
  }

  saveOrders(orders);
  openActionModal('Pedido guardado', 'Tu pedido se registró correctamente.', false, [
    { text: 'Ver pedidos ingresados', cls: 'btn-secondary', onClick: function() { window.location.href = 'pedidos-ingresados.html'; } }
  ]);
}

document.addEventListener('DOMContentLoaded', function() {
  const rawEditId = localStorage.getItem(STORAGE_KEYS.EDIT_ORDER_ID);
  if (rawEditId) {
    const targetId = parseInt(rawEditId, 10);
    const orders = getOrders();
    let found = null;
    for (let i = 0; i < orders.length; i++) {
      if (orders[i].id === targetId) {
        found = orders[i];
        break;
      }
    }
    if (found) {
      editingOrderId = found.id;
      document.getElementById('order-form-title').textContent = 'Editar pedido N° ' + found.id;
      document.getElementById('btn-cancel-edit').classList.remove('hidden');
      document.getElementById('ord-nombre').value = found.nombre;
      document.getElementById('ord-run').value = found.run;
      document.getElementById('ord-telefono').value = found.telefono;
      document.getElementById('ord-correo').value = found.correo;
      document.getElementById('ord-direccion').value = found.direccion;
      orderLines = [];
      for (let j = 0; j < found.items.length; j++) {
        const it = found.items[j];
        orderLines.push({
          cantidad: it.cantidad,
          texto: it.nombre,
          productoId: it.productoId,
          valorUnitario: it.valorUnitario
        });
      }
      orderLines.push({ cantidad: 1, texto: '', productoId: null, valorUnitario: 0 });
      renderOrderLines();
    } else {
      resetOrderForm();
    }
  } else {
    resetOrderForm();
  }

  document.getElementById('ord-run').addEventListener('input', function() { formatRunInput(this); });
  document.getElementById('btn-add-line').addEventListener('click', function() {
    orderLines.push({ cantidad: 1, texto: '', productoId: null, valorUnitario: 0 });
    renderOrderLines();
  });
  document.getElementById('btn-clear-order').addEventListener('click', resetOrderForm);
  document.getElementById('btn-cancel-edit').addEventListener('click', resetOrderForm);
  document.getElementById('btn-submit-order').addEventListener('click', submitOrder);
});
