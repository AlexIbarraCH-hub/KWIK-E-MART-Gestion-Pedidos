/* =========================================================
   HITO 4: PROCESAMIENTO DE PEDIDOS EN 2 PASOS (procesamiento.html)
   ========================================================= */
let selectedProcessOrderId = null;

function toggleSelectProcessOrder(id) {
  selectedProcessOrderId = selectedProcessOrderId === id ? null : id;
  renderProcessOrdersTable();
}

function renderProcessOrdersTable() {
  const orders = getOrders();
  const tbody = document.getElementById('tb-process-orders');

  if (orders.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-table-msg">No hay pedidos pendientes de procesamiento.</td></tr>';
    document.getElementById('btn-go-step2').disabled = true;
    return;
  }

  let html = '';
  for (let i = 0; i < orders.length; i++) {
    const o = orders[i];
    const isChecked = selectedProcessOrderId === o.id;
    html += '<tr class="' + (isChecked ? 'selected-row' : '') + '">' +
      '<td class="col-check"><input type="checkbox" ' + (isChecked ? 'checked' : '') + ' onchange="toggleSelectProcessOrder(' + o.id + ')"></td>' +
      '<td>' + o.id + '</td>' +
      '<td>' + o.nombre + '</td>' +
      '<td>' + o.correo + '</td>' +
      '<td>' + formatCLP(calcOrderTotal(o.items)) + '</td>' +
      '<td>' + (o.vb || '—') + '</td>' +
      '<td>' + (o.envio || '—') + '</td>' +
    '</tr>';
  }
  tbody.innerHTML = html;
  document.getElementById('btn-go-step2').disabled = selectedProcessOrderId === null;
}

function openProcessStep2() {
  if (selectedProcessOrderId === null) return;
  localStorage.setItem(STORAGE_KEYS.PROCESS_ORDER_ID, String(selectedProcessOrderId));

  const orders = getOrders();
  let order = null;
  for (let i = 0; i < orders.length; i++) {
    if (orders[i].id === selectedProcessOrderId) {
      order = orders[i];
      break;
    }
  }
  if (!order) return;

  document.getElementById('step2-order-title').textContent = 'Pedido N° ' + order.id;
  document.getElementById('ro-nombre').textContent = order.nombre;
  document.getElementById('ro-run').textContent = order.run;
  document.getElementById('ro-telefono').textContent = order.telefono;
  document.getElementById('ro-correo').textContent = order.correo;
  document.getElementById('ro-direccion').textContent = order.direccion;

  let html = '';
  for (let j = 0; j < order.items.length; j++) {
    const it = order.items[j];
    html += '<tr>' +
      '<td>' + it.cantidad + '</td>' +
      '<td>' + it.nombre + '</td>' +
      '<td>' + formatCLP(it.valorUnitario) + '</td>' +
      '<td>' + formatCLP(it.cantidad * it.valorUnitario) + '</td>' +
    '</tr>';
  }
  document.getElementById('tb-ro-items').innerHTML = html;
  document.getElementById('ro-total').textContent = formatCLP(calcOrderTotal(order.items));

  document.getElementById('sel-vb').value = '';
  const selEnvio = document.getElementById('sel-envio');
  selEnvio.innerHTML = '<option value="">Seleccionar...</option>';
  selEnvio.disabled = true;
  document.getElementById('vb-helper').classList.remove('hidden');
  document.getElementById('btn-accept-process').disabled = true;

  document.getElementById('view-process-step1').classList.add('hidden');
  document.getElementById('view-process-step2').classList.remove('hidden');
}

function handleVbChange() {
  const vb = document.getElementById('sel-vb').value;
  const selEnvio = document.getElementById('sel-envio');
  const helper = document.getElementById('vb-helper');

  if (!vb) {
    selEnvio.innerHTML = '<option value="">Seleccionar...</option>';
    selEnvio.disabled = true;
    helper.classList.remove('hidden');
  } else {
    helper.classList.add('hidden');
    selEnvio.disabled = false;
    if (vb === 'Sí') {
      selEnvio.innerHTML = '<option value="">Seleccionar...</option>' +
        '<option value="Bodega">Bodega</option>' +
        '<option value="Despacho">Despacho</option>' +
        '<option value="Retiro en tienda">Retiro en tienda</option>';
    } else {
      selEnvio.innerHTML = '<option value="">Seleccionar...</option>' +
        '<option value="Cliente (Rechazado)">Cliente (Rechazado)</option>' +
        '<option value="Revisión">Revisión</option>';
    }
  }
  validateProcessAccept();
}

function validateProcessAccept() {
  const vb = document.getElementById('sel-vb').value;
  const envio = document.getElementById('sel-envio').value;
  document.getElementById('btn-accept-process').disabled = !(vb && envio);
}

function confirmProcessOrder() {
  const vb = document.getElementById('sel-vb').value;
  const envio = document.getElementById('sel-envio').value;
  const orders = getOrders();
  let processedOrder = null;

  for (let i = 0; i < orders.length; i++) {
    if (orders[i].id === selectedProcessOrderId) {
      orders[i].vb = vb;
      orders[i].envio = envio;
      processedOrder = orders[i];
      break;
    }
  }
  saveOrders(orders);

  if (vb === 'Sí' && processedOrder) {
    const products = getProducts();
    for (let i = 0; i < processedOrder.items.length; i++) {
      for (let j = 0; j < products.length; j++) {
        if (products[j].id === processedOrder.items[i].productoId) {
          products[j].cantidad = Math.max(0, products[j].cantidad - processedOrder.items[i].cantidad);
          products[j].usado = true;
          if (products[j].cantidad === 0) {
            products[j].estado = 'Deshabilitado';
          }
          break;
        }
      }
    }
    saveProducts(products);
  }

  localStorage.removeItem(STORAGE_KEYS.PROCESS_ORDER_ID);
  openActionModal('Pedido procesado', 'V.B.: ' + vb + ' · Enviado a: ' + envio + '.', false, [
    { text: 'Volver al listado', cls: 'btn-secondary', onClick: function() {
      closeActionModal();
      document.getElementById('view-process-step2').classList.add('hidden');
      document.getElementById('view-process-step1').classList.remove('hidden');
      selectedProcessOrderId = null;
      renderProcessOrdersTable();
    }}
  ]);
}

document.addEventListener('DOMContentLoaded', function() {
  renderProcessOrdersTable();
  document.getElementById('btn-go-step2').addEventListener('click', openProcessStep2);
  document.getElementById('sel-vb').addEventListener('change', handleVbChange);
  document.getElementById('sel-envio').addEventListener('change', validateProcessAccept);
  document.getElementById('btn-accept-process').addEventListener('click', confirmProcessOrder);
  document.getElementById('btn-back-step1').addEventListener('click', function() {
    localStorage.removeItem(STORAGE_KEYS.PROCESS_ORDER_ID);
    document.getElementById('view-process-step2').classList.add('hidden');
    document.getElementById('view-process-step1').classList.remove('hidden');
    selectedProcessOrderId = null;
    renderProcessOrdersTable();
  });
});
