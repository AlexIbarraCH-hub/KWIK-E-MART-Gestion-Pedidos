/* =========================================================
   HITO 3: LISTADO, EDICIÓN Y ELIMINACIÓN DE PEDIDOS (pedidos-ingresados.html)
   ========================================================= */
let selectedOrderId = null;

function toggleSelectOrder(id) {
  selectedOrderId = selectedOrderId === id ? null : id;
  renderOrdersTable();
}

function renderOrdersTable() {
  const orders = getOrders();
  const tbody = document.getElementById('tb-orders');

  if (orders.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-table-msg">No hay pedidos ingresados todavía. Crea uno desde la sección Pedidos.</td></tr>';
    document.getElementById('btn-delete-order').disabled = true;
    document.getElementById('btn-edit-order').disabled = true;
    return;
  }

  let html = '';
  for (let i = 0; i < orders.length; i++) {
    const o = orders[i];
    const isChecked = selectedOrderId === o.id;
    html += '<tr class="' + (isChecked ? 'selected-row' : '') + '">' +
      '<td class="col-check"><input type="checkbox" ' + (isChecked ? 'checked' : '') + ' onchange="toggleSelectOrder(' + o.id + ')"></td>' +
      '<td>' + o.id + '</td>' +
      '<td>' + o.nombre + '</td>' +
      '<td>' + o.correo + '</td>' +
      '<td>' + o.telefono + '</td>' +
      '<td>' + formatCLP(calcOrderTotal(o.items)) + '</td>' +
    '</tr>';
  }
  tbody.innerHTML = html;
  document.getElementById('btn-delete-order').disabled = selectedOrderId === null;
  document.getElementById('btn-edit-order').disabled = selectedOrderId === null;
}

document.addEventListener('DOMContentLoaded', function() {
  renderOrdersTable();

  document.getElementById('btn-edit-order').addEventListener('click', function() {
    if (selectedOrderId === null) return;
    localStorage.setItem(STORAGE_KEYS.EDIT_ORDER_ID, String(selectedOrderId));
    window.location.href = 'pedidos.html';
  });

  document.getElementById('btn-delete-order').addEventListener('click', function() {
    if (selectedOrderId === null) return;
    const idToDelete = selectedOrderId;
    openActionModal('¿Eliminar pedido?', 'El pedido N° ' + idToDelete + ' se eliminará de forma permanente.', true, [
      { text: 'Cancelar', cls: 'btn-outline', onClick: closeActionModal },
      { text: 'Eliminar', cls: 'btn-danger', onClick: function() {
        const orders = getOrders();
        const remaining = [];
        for (let i = 0; i < orders.length; i++) {
          if (orders[i].id !== idToDelete) {
            remaining.push(orders[i]);
          }
        }
        saveOrders(remaining);
        selectedOrderId = null;
        closeActionModal();
        renderOrdersTable();
      }}
    ]);
  });
});
