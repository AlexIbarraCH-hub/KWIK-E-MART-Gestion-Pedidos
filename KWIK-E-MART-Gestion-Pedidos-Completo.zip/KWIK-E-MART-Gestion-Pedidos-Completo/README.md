# KWIK-E-MART-Gestion-Pedidos
Avance 3, Proyecto correspondiente a la "Evaluación 3" de interfaces de usuario. 
Integrantes del grupo
Alex Ibarra [Jefe de Grupo]
Matias Luna. 
Alvaro Díaz.
Mauricio Rojas.
---------------------------------------------------------------------------------
Credenciales de Prueba
° Perfil de Administrador: 
- Usuario = 'apu'
- Contraseña = 'admin123'
° Perfil de Usuario:
- Usuario = 'homero'
- Contraseña = 'donas123'
---------------------------------------------------------------------------------
Arquitectura por Hitos
1. Hitos 1 y 2 (Base del repositorio - Autenticación, Roles y Guardián de Rutas):
   - index.html
   - img/logo-kwik-e-mart.svg
   - js/auth.js
   - js/storage.js (inicialización de usuarios, productos y llaves STORAGE_KEYS)
   - css/styles.css (paleta 60-30-10, header, navbar, login, dashboard, modales y footer)

2. Hitos 3 y 4 (Vistas de Operación conectadas a STORAGE_KEYS):
   - pedidos.html + js/pedidos.js (creación y edición de pedidos con validación de RUN y stock)
   - pedidos-ingresados.html + js/pedidos-ingresados.js (listado, selección, edición y eliminación)
   - productos.html + js/productos.js (CRUD de productos y regla automática de stock 0)
   - procesamiento.html + js/procesamiento.js (procesamiento en 2 pasos, V.B., destino de envío y descuento de stock)
---------------------------------------------------------------------------------
Instrucciones de Ejecución
1. Abrir index.html en un navegador web moderno (o mediante Live Server).
2. Iniciar sesión con 'homero' / 'donas123' (Perfil Usuario) o 'apu' / 'admin123' (Perfil Administrador).
